# IMPORT LIBRARIES
import json
import math
from webob import Response
from ryu.app.wsgi import ControllerBase, WSGIApplication, route
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_0
from ryu.lib.mac import haddr_to_bin
from ryu.lib.packet import packet
from ryu.lib.packet.packet import Packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import arp
from ryu.lib.packet import ipv4
from ryu.lib.packet import tcp
from ryu.lib.packet import udp
from ryu.lib.packet import ether_types
from ryu.ofproto import ether
from ryu.app.ofctl.api import get_datapath
from datetime import datetime


# REST API for switch configuration
#
# get switches
# GET /v1.0/lookup/switches
#
# get bridge-table
# GET /v1.0/lookup/bridge-table
#
# get lookup
# GET /v1.0/lookup/lookup
#
# get ip-to-mac
# GET /v1.0/lookup/ip-to-mac

IP     = 0
SUBNET = 1
MAC    = 2
NAME   = 3
DPID   = 4
#########################################################
NROW   = 8   #numero di switch con stessa lunghezza del prefisso (max righe della tabella)

#########################################################

#funzione da decimale a binario
def fromIPtoBinary(string):
	w1, w2, w3, w4 = string.split(".")
	binaryN = [ str(bin(int(w1)))[2:], str(bin(int(w2)))[2:], str(bin(int(w3)))[2:], str(bin(int(w4)))[2:]]
	binaryN = paddingAddress(binaryN)
	addressIP = binaryN[0]
	i=1
	while i<4:
		addressIP = addressIP+binaryN[i]
		i=i+1
	return str(addressIP)

#funzione per portare i vari numeri dell'indirizzo IP a binari a 8 cifre
def paddingAddress(list):
	i = 0
	padded_list = list;
	while i < len(list):
		if len(list)<8:
			while len(padded_list[i]) < 8:
				padded_list[i] = '0' + padded_list[i]
		i = i + 1
	return padded_list
	
	
ipLookUp = [ipLookUp[:] for ipLookUp in [[0]*(32-1)]*31]
marker = [marker[:] for marker in [[0]*(32-1)]*31]
#tabella dei prefissi
ipLookUp[0] = ['']
ipLookUp[1] = ['']
ipLookUp[2] = ['']
ipLookUp[3] = ['1100','1000','1010','0011','0000','0010','1001','1011','1101']
ipLookUp[4] = ['11001','00101']
ipLookUp[5] = ['100001','001111','000010','000011','001001','101101','110110']
ipLookUp[6] = ['1000010','0011110','0010011']
ipLookUp[7] = ['11000001','11000000','10100011','01110110','10011111','00001010','11000011','00100001','00110010','00101100','10011110','10000111','00100000','00010001','00001001','00010110','01000111','1100000','11011100','11011110']
ipLookUp[8] = ['001100101','000100011','110111100','101000110']
ipLookUp[9] = ['0011001010','0000100101','0001011001','0100011101','1101110010']
ipLookUp[10] = ['00110010101','00010110011','01000111011']
ipLookUp[11] = ['001000010110','101110010101','001011001000','100001111011','110000010110']
ipLookUp[12] = ['']
ipLookUp[13] = ['00101100100001','00100000110011'] 
ipLookUp[14] = ['001011001000011','110000010110100']                                                                            
ipLookUp[15] = ['0111011111000010','0100000100110100','1101111100100100','0011111010000101','1011001101000101']
ipLookUp[16] = ['01110111110000100']
ipLookUp[17] = ['101110000010110100']
ipLookUp[18] = ['1011100000101101001']
ipLookUp[19] = ['01000001001101001110','11011111001001001101']
ipLookUp[20] = ['110111110010010011011']
ipLookUp[21] = ['']
ipLookUp[22] = ['']
ipLookUp[23] = ['001011010101100011110101']
ipLookUp[24] = ['']
ipLookUp[25] = ['']
ipLookUp[26] = ['']
ipLookUp[27] = ['']
ipLookUp[28] = ['']
ipLookUp[29] = ['']
ipLookUp[30] = ['']

#tabella marker
marker[7] = ['10111001']
marker[11] = ['001000001100']
marker[13] = ['11000001011010']
marker[15] = ['1011100000101101','0010110101011000']


#index di partenza per la ricerca
index = int(round(len(ipLookUp)/2)+1)

#profondita' del percorso dell'algoritmo
deepMax = int(math.log(len(ipLookUp)+1,2))
deep = 0

#dizionario per mappatura prefisso-indirizzo di rete
binary2ip = {}
binary2ip['00001010']='10.0.0.254'
binary2ip['11000011']='195.0.0.254'
binary2ip['001000010110']='33.96.0.254'
binary2ip['101110010101']='185.80.0.254'                #switch18 marker(h44, h45)
binary2ip['1000010']='132.0.0.254'
binary2ip['00110010101']='50.160.0.254'
binary2ip['001011001000011']='44.134.0.254'
binary2ip['1011001101000101']='179.69.0.254'
binary2ip['01110111110000100']='119.194.0.254'
binary2ip['1011100000101101001']='184.45.32.254'        #switch38 marker (h92, h93)
binary2ip['01000001001101001110']='65.52.224.254'
binary2ip['110111110010010011011']='223.36.216.254'
binary2ip['001011010101100011110101']='45.88.245.254'   #switch45 marker (h108, h109)
binary2ip['10011111']='159.0.0.254'
binary2ip['101101']='180.0.0.254'
binary2ip['11001']='200.0.0.254'
binary2ip['0011111010000101']='62.133.0.254'
binary2ip['10011110']='158.0.0.254'
binary2ip['100001111011']='135.176.0.254'               #errore dell'algoritmo con 132   
binary2ip['110111100']='222.0.0.254'
binary2ip['0011110']='60.0.0.254'
binary2ip['110110']='216.0.0.254'
binary2ip['01110110']='118.0.0.254'
binary2ip['000011']='12.0.0.254'
binary2ip['00100000110011']='32.204.0.254'              #switch4 marker (h8, h9)
binary2ip['0010011']='38.0.0.254'
binary2ip['00101']='40.0.0.254'
binary2ip['101000110']='163.0.0.254'
binary2ip['000100011']='17.128.0.254'
binary2ip['0000100101']='9.64.0.254'
binary2ip['00010110011']='22.96.0.254'
binary2ip['01000111011']='71.96.0.254'
binary2ip['11000000']='192.0.0.254'
binary2ip['110000010110100']='193.105.0.254'            #switch16 marker (h38, h39)
binary2ip['1101110010']='220.160.0.254'



#costruzione passaggi dell'algoritmo
tree = [tree[:] for tree in [[0]*(31)]*(deepMax)]
for x in range(0,deepMax):
    riga=index
    
    for y in range (0,((2**(x+1))-1)):
     
        tree[x][y]=riga
        riga = riga + index
    
    index = int(index/2)

#variabili globali algoritmo
index = 0
gateway = 0

#ricerca di un valore
def ricerca(ipLookedFor,deepCurrent,index):
    global gateway
    #print "ricercato",ipLookedFor  
    ipCut = ipLookedFor[0:tree[deepCurrent][index]]
    #print "\nipCut: ",ipCut
    #print "index: ",tree[deepCurrent][index]
    #print "Tabella ",ipLookUp[tree[deepCurrent][index]-1]
    trovato = 0
    if(deepCurrent < deepMax):
        if ipCut in ipLookUp[tree[deepCurrent][index]-1]:
            #print "ip trovato"
            #print "Tagliato",ipCut
            gateway = ipCut
            if(deepCurrent < deepMax-1):
                index = tree[deepCurrent+1].index(tree[deepCurrent][index]) +1
        else:
            if ipCut in marker[tree[deepCurrent][index]-1]:
                #print "ho trovato un marker"
                index = tree[deepCurrent+1].index(tree[deepCurrent][index]) +1
            else:
                #print "ip NON trovato"
                if(deepCurrent < deepMax-1):
                    index = tree[deepCurrent+1].index(tree[deepCurrent][index]) -1

    deepCurrent = deepCurrent+1
    
    if (deepCurrent < deepMax and tree[deepCurrent][index] != 0):
        ricerca(ipLookedFor,deepCurrent,index)
    else:
        #print ipCut
        
        return 

########################################################

# Main class for switch
class SimpleSwitch(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_0.OFP_VERSION]
    _CONTEXTS = {
        'wsgi': WSGIApplication
    }

    # Initialize the application 
    def __init__(self, *args, **kwargs):
        super(SimpleSwitch, self).__init__(*args, **kwargs)
        wsgi = kwargs['wsgi']
        wsgi.register(LookupController, {'lookup_api_app': self})

        # Add all initialization code here
        self.mac_to_port = {} 
        self.mac_to_port["1"] = {}
        self.mac_to_port["7"] = {}
        self.mac_to_port["14"] = {}
        self.mac_to_port["18"] = {}
	self.mac_to_port["22"] = {}
	self.mac_to_port["23"] = {}
	self.mac_to_port["26"] = {}
	self.mac_to_port["31"] = {}
	self.mac_to_port["35"] = {}
	self.mac_to_port["38"] = {}
	self.mac_to_port["40"] = {}
	self.mac_to_port["43"] = {}
	self.mac_to_port["45"] = {}
	self.mac_to_port["49"] = {}
	self.mac_to_port["52"] = {}
	self.mac_to_port["53"] = {}
	self.mac_to_port["54"] = {}
	self.mac_to_port["55"] = {}
	self.mac_to_port["56"] = {}
	self.mac_to_port["57"] = {}
	self.mac_to_port["58"] = {}
	self.mac_to_port["59"] = {}
	self.mac_to_port["2"] = {}
	self.mac_to_port["3"] = {}
	self.mac_to_port["4"] = {}
	self.mac_to_port["5"] = {}
	self.mac_to_port["8"] = {}
	self.mac_to_port["9"] = {}
	self.mac_to_port["10"] = {}
	self.mac_to_port["11"] = {}
	self.mac_to_port["12"] = {}
	self.mac_to_port["13"] = {}
	self.mac_to_port["15"] = {}
	self.mac_to_port["16"] = {}
	self.mac_to_port["17"] = {}



        self.mac_to_port["1"]["00:00:00:00:00:01"] = 1
        self.mac_to_port["1"]["00:00:00:00:00:02"] = 2
        self.mac_to_port["2"]["00:00:00:00:00:03"] = 1
	self.mac_to_port["2"]["00:00:00:00:00:04"] = 2
	self.mac_to_port["3"]["00:00:00:00:00:05"] = 1
	self.mac_to_port["3"]["00:00:00:00:00:06"] = 2
	self.mac_to_port["3"]["00:00:00:00:00:07"] = 3
	self.mac_to_port["4"]["00:00:00:00:00:08"] = 1
	self.mac_to_port["4"]["00:00:00:00:00:09"] = 2
	self.mac_to_port["5"]["00:00:00:00:00:0a"] = 1
	self.mac_to_port["5"]["00:00:00:00:00:0b"] = 2
        self.mac_to_port["7"]["00:00:00:00:00:0c"] = 1
        self.mac_to_port["7"]["00:00:00:00:00:0d"] = 2
        self.mac_to_port["8"]["00:00:00:00:00:0e"] = 1
	self.mac_to_port["8"]["00:00:00:00:00:0f"] = 2
	self.mac_to_port["9"]["00:00:00:00:00:10"] = 1
	self.mac_to_port["9"]["00:00:00:00:00:11"] = 2
	self.mac_to_port["10"]["00:00:00:00:00:12"] = 1
	self.mac_to_port["10"]["00:00:00:00:00:13"] = 2
	self.mac_to_port["10"]["00:00:00:00:00:14"] = 3
	self.mac_to_port["11"]["00:00:00:00:00:15"] = 1
	self.mac_to_port["11"]["00:00:00:00:00:16"] = 2
	self.mac_to_port["11"]["00:00:00:00:00:17"] = 3
	self.mac_to_port["12"]["00:00:00:00:00:18"] = 1
	self.mac_to_port["12"]["00:00:00:00:00:19"] = 2
	self.mac_to_port["13"]["00:00:00:00:00:1a"] = 1
	self.mac_to_port["13"]["00:00:00:00:00:1b"] = 2
	self.mac_to_port["13"]["00:00:00:00:00:1c"] = 3
	self.mac_to_port["13"]["00:00:00:00:00:1d"] = 4
        self.mac_to_port["14"]["00:00:00:00:00:1e"] = 1
        self.mac_to_port["14"]["00:00:00:00:00:1f"] = 2
        self.mac_to_port["15"]["00:00:00:00:00:20"] = 1
	self.mac_to_port["15"]["00:00:00:00:00:21"] = 2
	self.mac_to_port["16"]["00:00:00:00:00:22"] = 1
	self.mac_to_port["16"]["00:00:00:00:00:23"] = 2
	self.mac_to_port["16"]["00:00:00:00:00:24"] = 3
	self.mac_to_port["17"]["00:00:00:00:00:25"] = 1
	self.mac_to_port["17"]["00:00:00:00:00:26"] = 2
	self.mac_to_port["17"]["00:00:00:00:00:27"] = 3
	self.mac_to_port["17"]["00:00:00:00:00:28"] = 4
        self.mac_to_port["18"]["00:00:00:00:00:29"] = 1
        self.mac_to_port["18"]["00:00:00:00:00:2a"] = 2
        self.mac_to_port["22"]["00:00:00:00:00:2b"] = 1
	self.mac_to_port["22"]["00:00:00:00:00:2c"] = 2
	self.mac_to_port["22"]["00:00:00:00:00:2d"] = 3
	self.mac_to_port["23"]["00:00:00:00:00:2e"] = 1
	self.mac_to_port["23"]["00:00:00:00:00:2f"] = 2
	self.mac_to_port["23"]["00:00:00:00:00:30"] = 3
	self.mac_to_port["23"]["00:00:00:00:00:31"] = 4
	self.mac_to_port["26"]["00:00:00:00:00:32"] = 1
	self.mac_to_port["26"]["00:00:00:00:00:33"] = 2
	self.mac_to_port["31"]["00:00:00:00:00:34"] = 1
	self.mac_to_port["31"]["00:00:00:00:00:35"] = 2
	self.mac_to_port["35"]["00:00:00:00:00:36"] = 1
	self.mac_to_port["35"]["00:00:00:00:00:37"] = 2
	self.mac_to_port["38"]["00:00:00:00:00:38"] = 1
	self.mac_to_port["38"]["00:00:00:00:00:39"] = 2
	self.mac_to_port["40"]["00:00:00:00:00:3a"] = 1
	self.mac_to_port["40"]["00:00:00:00:00:3b"] = 2
	self.mac_to_port["40"]["00:00:00:00:00:3c"] = 3
	self.mac_to_port["43"]["00:00:00:00:00:3d"] = 1
	self.mac_to_port["43"]["00:00:00:00:00:3e"] = 2
	self.mac_to_port["45"]["00:00:00:00:00:3f"] = 1
	self.mac_to_port["45"]["00:00:00:00:00:40"] = 2
	self.mac_to_port["49"]["00:00:00:00:00:41"] = 1
	self.mac_to_port["49"]["00:00:00:00:00:42"] = 2
	self.mac_to_port["52"]["00:00:00:00:00:43"] = 1
	self.mac_to_port["52"]["00:00:00:00:00:44"] = 2
	self.mac_to_port["53"]["00:00:00:00:00:45"] = 1
	self.mac_to_port["53"]["00:00:00:00:00:46"] = 2
	self.mac_to_port["54"]["00:00:00:00:00:47"] = 1
	self.mac_to_port["54"]["00:00:00:00:00:48"] = 2
	self.mac_to_port["54"]["00:00:00:00:00:49"] = 3
	self.mac_to_port["55"]["00:00:00:00:00:4a"] = 1
	self.mac_to_port["55"]["00:00:00:00:00:4b"] = 2
	self.mac_to_port["55"]["00:00:00:00:00:4c"] = 3
	self.mac_to_port["56"]["00:00:00:00:00:4d"] = 1
	self.mac_to_port["56"]["00:00:00:00:00:4e"] = 2
	self.mac_to_port["56"]["00:00:00:00:00:4f"] = 3
	self.mac_to_port["57"]["00:00:00:00:00:50"] = 1
	self.mac_to_port["57"]["00:00:00:00:00:51"] = 2
	self.mac_to_port["57"]["00:00:00:00:00:52"] = 3
	self.mac_to_port["58"]["00:00:00:00:00:53"] = 1
	self.mac_to_port["58"]["00:00:00:00:00:54"] = 2
	self.mac_to_port["59"]["00:00:00:00:00:55"] = 1
	self.mac_to_port["59"]["00:00:00:00:00:56"] = 2
	self.mac_to_port["59"]["00:00:00:00:00:57"] = 3
        
	
        self.switch = {}
        self.switch["10.0.0.254"  ] = ["10.0.0.254","8" ,"00:00:00:11:11:01","s1","1"]
        self.switch["118.0.0.254"] = ["118.0.0.254", "8", "00:00:00:11:11:02", "s2", "2"]
	self.switch["12.0.0.254"] = ["12.0.0.254", "6", "00:00:00:11:11:03", "s3", "3"]
	self.switch["32.204.0.254"] = ["32.204.0.254", "14", "00:00:00:11:11:04", "s4", "4"]
	self.switch["38.0.0.254"] = ["38.0.0.254", "7", "00:00:00:11:11:05", "s5", "5"]
        self.switch["195.0.0.254"] = ["195.0.0.254", "8", "00:00:00:11:11:06", "s7", "7"]
        self.switch["40.0.0.254"] = ["40.0.0.254", "5", "00:00:00:11:11:07", "s8", "8"]
	self.switch["163.0.0.254"] = ["163.0.0.254", "9", "00:00:00:11:11:08", "s9", "9"]
	self.switch["17.128.0.254"] = ["17.128.0.254", "9", "00:00:00:11:11:09", "s10", "10"]
	self.switch["9.64.0.254"] = ["9.64.0.254", "10", "00:00:00:11:11:0a", "s11", "11"]
	self.switch["22.96.0.254"] = ["22.96.0.254", "11", "00:00:00:11:11:0b", "s12", "12"]
	self.switch["71.96.0.254"] = ["71.96.0.254", "11", "00:00:00:11:11:0c", "s13", "13"]
        self.switch["33.96.0.254"] = ["33.96.0.254", "12", "00:00:00:11:11:0d", "s14", "14"]
        self.switch["192.0.0.254"] = ["192.0.0.254", "8", "00:00:00:11:11:0e", "s15", "15"]
	self.switch["193.105.0.254"] = ["193.105.0.254", "15", "00:00:00:11:11:0f", "s16", "16"]
	self.switch["220.160.0.254"] = ["220.160.0.254", "10", "00:00:00:11:11:10", "s17", "17"]
        self.switch["185.80.0.254"] = ["185.80.0.254", "12", "00:00:00:11:11:11", "s18", "18"]
        self.switch["132.0.0.254"] = ["132.0.0.254", "7", "00:00:00:11:11:12", "s22", "22"]
	self.switch["50.160.0.254"] = ["50.160.0.254", "11", "00:00:00:11:11:13", "s23", "23"]
	self.switch["44.134.0.254"] = ["44.134.0.254", "15", "00:00:00:11:11:14", "s26", "26"]
	self.switch["179.69.0.254"] = ["179.69.0.254", "16", "00:00:00:11:11:15", "s31", "31"]
	self.switch["119.194.0.254"] = ["119.194.0.254", "17", "00:00:00:11:11:16", "s35", "35"]
	self.switch["184.45.32.254"] = ["184.45.32.254", "19", "00:00:00:11:11:17", "s38", "38"]
	self.switch["65.52.224.254"] = ["65.52.224.254", "20", "00:00:00:11:11:18", "s40", "40"]
	self.switch["223.36.216.254"] = ["223.36.216.254", "21", "00:00:00:11:11:19", "s43", "43"]
	self.switch["45.88.245.254"] = ["45.88.245.254", "24", "00:00:00:11:11:1a", "s45", "45"]
	self.switch["159.0.0.254"] = ["159.0.0.254", "8", "00:00:00:11:11:1b", "s49", "49"]
	self.switch["180.0.0.254"] = ["180.0.0.254", "6", "00:00:00:11:11:1c", "s52", "52"]
	self.switch["200.0.0.254"] = ["200.0.0.254", "5", "00:00:00:11:11:1d", "s53", "53"]
	self.switch["62.133.0.254"] = ["62.133.0.254", "16", "00:00:00:11:11:1e", "s54", "54"]
	self.switch["158.0.0.254"] = ["158.0.0.254", "8", "00:00:00:11:11:1f", "s55", "55"]
	self.switch["135.176.0.254"] = ["135.176.0.254", "12", "00:00:00:11:11:20", "s56", "56"]
	self.switch["222.0.0.254"] = ["222.0.0.254", "9", "00:00:00:11:11:21", "s57", "57"]
	self.switch["60.0.0.254"] = ["60.0.0.254", "7", "00:00:00:11:11:22", "s58", "58"]
	self.switch["216.0.0.254"] = ["216.0.0.254", "6", "00:00:00:11:11:23", "s59", "59"]
	      
	

        self.ip_to_mac = {}
        self.ip_to_mac["10.0.0.1"] = "00:00:00:00:00:01"
        self.ip_to_mac["10.0.0.2"] = "00:00:00:00:00:02"
        self.ip_to_mac["118.0.0.1"] = "00:00:00:00:00:03"
	self.ip_to_mac["118.0.0.2"] = "00:00:00:00:00:04"
	self.ip_to_mac["12.0.0.1"] = "00:00:00:00:00:05"
	self.ip_to_mac["12.0.0.2"] = "00:00:00:00:00:06"
	self.ip_to_mac["12.0.0.3"] = "00:00:00:00:00:07"
	self.ip_to_mac["32.204.0.1"] = "00:00:00:00:00:08"
	self.ip_to_mac["32.204.0.2"] = "00:00:00:00:00:09"
	self.ip_to_mac["38.0.0.1"] = "00:00:00:00:00:0a"
	self.ip_to_mac["38.0.0.2"] = "00:00:00:00:00:0b"
        self.ip_to_mac["195.0.0.1"] = "00:00:00:00:00:0c"
        self.ip_to_mac["195.0.0.2"] = "00:00:00:00:00:0d"
        self.ip_to_mac["40.0.0.1"] = "00:00:00:00:00:0e"
	self.ip_to_mac["40.0.0.2"] = "00:00:00:00:00:0f"
	self.ip_to_mac["163.0.0.1"] = "00:00:00:00:00:10"
	self.ip_to_mac["163.0.0.2"] = "00:00:00:00:00:11"
	self.ip_to_mac["17.128.0.1"] = "00:00:00:00:00:12"
	self.ip_to_mac["17.128.0.2"] = "00:00:00:00:00:13"
	self.ip_to_mac["17.128.0.3"] = "00:00:00:00:00:14"
	self.ip_to_mac["9.64.0.1"] = "00:00:00:00:00:15"
	self.ip_to_mac["9.64.0.2"] = "00:00:00:00:00:16"
	self.ip_to_mac["9.64.0.3"] = "00:00:00:00:00:17"
	self.ip_to_mac["22.96.0.1"] = "00:00:00:00:00:18"
	self.ip_to_mac["22.96.0.2"] = "00:00:00:00:00:19"
	self.ip_to_mac["71.96.0.1"] = "00:00:00:00:00:1a"
	self.ip_to_mac["71.96.0.2"] = "00:00:00:00:00:1b"
	self.ip_to_mac["71.96.0.3"] = "00:00:00:00:00:1c"
	self.ip_to_mac["71.96.0.4"] = "00:00:00:00:00:1d"
	self.ip_to_mac["33.96.0.1"] = "00:00:00:00:00:1e"
        self.ip_to_mac["33.96.0.2"] = "00:00:00:00:00:1f"
        self.ip_to_mac["192.0.0.1"] = "00:00:00:00:00:20"
	self.ip_to_mac["192.0.0.2"] = "00:00:00:00:00:21"
	self.ip_to_mac["193.105.0.1"] = "00:00:00:00:00:22"
	self.ip_to_mac["193.105.0.2"] = "00:00:00:00:00:23"
	self.ip_to_mac["193.105.0.3"] = "00:00:00:00:00:24"
	self.ip_to_mac["220.160.0.1"] = "00:00:00:00:00:25"
	self.ip_to_mac["220.160.0.2"] = "00:00:00:00:00:26"
	self.ip_to_mac["220.160.0.3"] = "00:00:00:00:00:27"
	self.ip_to_mac["220.160.0.4"] = "00:00:00:00:00:28"
        self.ip_to_mac["185.80.0.1"] = "00:00:00:00:00:29"
        self.ip_to_mac["185.80.0.2"] = "00:00:00:00:00:2a"
        self.ip_to_mac["132.0.0.1"] = "00:00:00:00:00:2b"
        self.ip_to_mac["132.0.0.2"] = "00:00:00:00:00:2c"
        self.ip_to_mac["132.0.0.3"] = "00:00:00:00:00:2d"
	self.ip_to_mac["50.160.0.1"] = "00:00:00:00:00:2e"
        self.ip_to_mac["50.160.0.2"] = "00:00:00:00:00:2f"
        self.ip_to_mac["50.160.0.3"] = "00:00:00:00:00:30"
        self.ip_to_mac["50.160.0.4"] = "00:00:00:00:00:31"
	self.ip_to_mac["44.134.0.1"] = "00:00:00:00:00:32"
        self.ip_to_mac["44.134.0.2"] = "00:00:00:00:00:33"
        self.ip_to_mac["179.69.0.1"] = "00:00:00:00:00:34"
        self.ip_to_mac["179.69.0.2"] = "00:00:00:00:00:35"
        self.ip_to_mac["119.194.0.1"] = "00:00:00:00:00:36"
        self.ip_to_mac["119.194.0.2"] = "00:00:00:00:00:37"
	self.ip_to_mac["184.45.32.1"] = "00:00:00:00:00:38"
        self.ip_to_mac["184.45.32.2"] = "00:00:00:00:00:39"
        self.ip_to_mac["65.52.224.1"] = "00:00:00:00:00:3a"
        self.ip_to_mac["65.52.224.2"] = "00:00:00:00:00:3b"
        self.ip_to_mac["65.52.224.3"] = "00:00:00:00:00:3c"
        self.ip_to_mac["223.36.216.1"] = "00:00:00:00:00:3d"
        self.ip_to_mac["223.36.216.2"] = "00:00:00:00:00:3e"
	self.ip_to_mac["45.88.245.1"] = "00:00:00:00:00:3f"
        self.ip_to_mac["45.88.245.2"] = "00:00:00:00:00:40"
	self.ip_to_mac["159.0.0.1"] = "00:00:00:00:00:41"
        self.ip_to_mac["159.0.0.2"] = "00:00:00:00:00:42"
        self.ip_to_mac["180.0.0.1"] = "00:00:00:00:00:43"
        self.ip_to_mac["180.0.0.2"] = "00:00:00:00:00:44"
        self.ip_to_mac["200.0.0.1"] = "00:00:00:00:00:45"
        self.ip_to_mac["200.0.0.2"] = "00:00:00:00:00:46"
	self.ip_to_mac["62.133.0.1"] = "00:00:00:00:00:47"
        self.ip_to_mac["62.133.0.2"] = "00:00:00:00:00:48"
        self.ip_to_mac["62.133.0.3"] = "00:00:00:00:00:49"
	self.ip_to_mac["158.0.0.1"] = "00:00:00:00:00:4a"
        self.ip_to_mac["158.0.0.2"] = "00:00:00:00:00:4b"
        self.ip_to_mac["158.0.0.3"] = "00:00:00:00:00:4c"
	self.ip_to_mac["135.176.0.1"] = "00:00:00:00:00:4d"
	self.ip_to_mac["135.176.0.2"] = "00:00:00:00:00:4e"
	self.ip_to_mac["135.176.0.3"] = "00:00:00:00:00:4f"
	self.ip_to_mac["222.0.0.1"] = "00:00:00:00:00:50"
        self.ip_to_mac["222.0.0.2"] = "00:00:00:00:00:51"
        self.ip_to_mac["222.0.0.3"] = "00:00:00:00:00:52"
	self.ip_to_mac["60.0.0.1"] = "00:00:00:00:00:53"
	self.ip_to_mac["60.0.0.2"] = "00:00:00:00:00:54"
	self.ip_to_mac["216.0.0.1"] = "00:00:00:00:00:55"
	self.ip_to_mac["216.0.0.2"] = "00:00:00:00:00:56"
	self.ip_to_mac["216.0.0.3"] = "00:00:00:00:00:57"

    def send_arp_reply(self, datapath, srcMac, srcIp, dstMac, dstIp, outPort):
        e = ethernet.ethernet(dstMac, srcMac, ether.ETH_TYPE_ARP)
        a = arp.arp(1, 0x0800, 6, 4, 2, srcMac, srcIp, dstMac, dstIp)
        p = Packet()
        p.add_protocol(e)
        p.add_protocol(a)
        p.serialize()

        actions = [datapath.ofproto_parser.OFPActionOutput(outPort, 0)]
        out = datapath.ofproto_parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=0xffffffff,
            in_port=datapath.ofproto.OFPP_CONTROLLER,
            actions=actions,
            data=p.data)
        datapath.send_msg(out)

  
          
    # Register PACKET HANDLER
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg                          # OpenFlow event message
        datapath = msg.datapath               # Switch class that received the packet   
        ofproto = datapath.ofproto            # OpenFlow protocol class  

        # Parse packet
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)

        # Ignore lldp packet
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        dst = eth.dst
        
        src = eth.src
        dpid = datapath.id

        self.logger.info("--Packet IN: Switch id[%s], Src MAC[%s], Dst MAC[%s], Port[%s]", dpid, src, dst, msg.in_port)
        action = "allow"

        if dst == 'ff:ff:ff:ff:ff:ff': 
            self.logger.info("  Broadcast packet")
            if eth.ethertype == ether_types.ETH_TYPE_ARP:
                arp_packet = pkt.get_protocol(arp.arp)
                if arp_packet.opcode == 1:
                    arp_dst_ip = arp_packet.dst_ip
                    arp_src_ip = arp_packet.src_ip
                    self.logger.info("  Received ARP request for dst IP %s" % arp_dst_ip)
                    if arp_dst_ip in self.switch:
                        switch_mac = self.switch[arp_dst_ip][MAC]

                        self.send_arp_reply(datapath,switch_mac,arp_packet.dst_ip,src,arp_src_ip,msg.in_port) 
                        self.logger.info("  Sent gratious ARP reply [%s]-[%s] to %s " % 
                                         (arp_packet.dst_ip,switch_mac,arp_packet.src_ip))  

                        return 0


            actions = [datapath.ofproto_parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
            data = None
            if msg.buffer_id == ofproto.OFP_NO_BUFFER:   #packet is not buffered on switch
                data = msg.data

            out = datapath.ofproto_parser.OFPPacketOut(
                datapath=datapath, buffer_id=msg.buffer_id, in_port=msg.in_port,
                actions=actions, data=data)
            self.logger.info("  Flooding packet to all other ports")
            datapath.send_msg(out)
            return


        ip4_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip4_pkt:
            global gateway
            self.logger.info("  --- IP LOOKUP")
            src_ip = ip4_pkt.src
            dst_ip = ip4_pkt.dst
            self.logger.info("  --- src_ip[%s], dst_ip[%s]" % (src_ip,dst_ip))
            durations = open("/home/user/Downloads/ryu/ryu/app/log_grande_p.txt","a")
            ipLookedFor = fromIPtoBinary(dst_ip)
	    t1 = datetime.now()
	    ricerca(ipLookedFor,deep,index);
	    t2 = datetime.now()
	    self.logger.info('\n\n##########Duration: {}'.format(t2 - t1))
	    self.logger.info('\n########### Gw : %s' %gateway)
	    sw = binary2ip[gateway]
	    durations.write(str(self.switch[sw][1])+'#'+ str((t2-t1).microseconds)+'\r\n')
	    #durations.writelines('\r\nGateway: ' + sw)
	    #durations.write('\r\nMask: /' + self.switch[sw][1])
	    #durations.write('\r\nDestination: ' + dst_ip)
	    #durations.write('\r\nSource: ' + src_ip)
	    #durations.write('\r\n##########Duration: {}'.format(t2 - t1))
	    gateway = None
			
            if sw is not None:
            #if dst_ip in self.lookup:
                #sw = self.lookup[dst_ip]
                
                self.logger.info("  --- Destination present on switch %s" % (self.switch[sw]))
                dp = get_datapath(self,int(self.switch[sw][DPID]))

                out_port = self.mac_to_port[self.switch[sw][DPID]][self.ip_to_mac[dst_ip]] 
                self.logger.info("  --- Output port set to %s" % (out_port))

                actions = [dp.ofproto_parser.OFPActionOutput(int(out_port))]

                data = msg.data
                pkt = packet.Packet(data)
                eth = pkt.get_protocol(ethernet.ethernet)
                #change the mac address of packet
                eth.dst = self.ip_to_mac[dst_ip] 
                self.logger.info("  --- Changing destination mac to %s" % (eth.dst))

                pkt.serialize()
                out = dp.ofproto_parser.OFPPacketOut(
                    datapath=dp, buffer_id=0xffffffff, in_port=datapath.ofproto.OFPP_CONTROLLER,
                    actions=actions, data=pkt.data)
                print("---------")
                dp.send_msg(out)
                return





        # Forward the packet 
        if dst in self.mac_to_port[str(dpid)]:
            out_port = self.mac_to_port[str(dpid)][dst]
            self.logger.info("  Destination MAC is on port %s. Forwarding the packet", out_port)
        else:
            out_port =  ofproto.OFPP_FLOOD
            self.logger.info("  Destination MAC not present in table. Flood the packet")

        actions = [datapath.ofproto_parser.OFPActionOutput(int(out_port))]

        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data

        out = datapath.ofproto_parser.OFPPacketOut(
            datapath=datapath, buffer_id=msg.buffer_id, in_port=msg.in_port,
            actions=actions, data=data)
        datapath.send_msg(out)

class LookupController(ControllerBase):
    def __init__(self, req, link, data, **config):
        super(LookupController, self).__init__(req, link, data, **config)
        self.lookup_api_app = data['lookup_api_app']

    @route('lookup', '/v1.0/lookup/lookup',
           methods=['GET'])
    def list_lookup(self, req, **kwargs):
        lookup_table = self.lookup_api_app.lookup
        body = json.dumps(lookup_table, sort_keys=True)
        return Response(content_type='application/json', body=body)

    
    @route('lookup', '/v1.0/lookup/switches',
           methods=['GET'])
    def list_switch(self, req, **kwargs):
        switch_table = self.lookup_api_app.switch
        body = json.dumps(switch_table, sort_keys=True)
        return Response(content_type='application/json', body=body)


    @route('lookup', '/v1.0/lookup/bridge-table',
           methods=['GET'])
    def list_bridge_table(self, req, **kwargs):
        bridge_table = self.lookup_api_app.mac_to_port
        body = json.dumps(bridge_table, sort_keys=True)
        return Response(content_type='application/json', body=body)

    @route('lookup', '/v1.0/lookup/ip-to-mac',
           methods=['GET'])
    def list_ip_to_mac_table(self, req, **kwargs):
        ip_to_mac_table = self.lookup_api_app.ip_to_mac
        body = json.dumps(ip_to_mac_table, sort_keys=True)
        return Response(content_type='application/json', body=body)


