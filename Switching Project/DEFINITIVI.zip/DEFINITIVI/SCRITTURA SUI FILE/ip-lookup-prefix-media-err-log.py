# IMPORT LIBRARIES
import json
import math
from webob import Response
from ryu.app.wsgi import ControllerBase, WSGIApplication, route
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_0
from ryu.lib.mac import haddr_to_bin
from ryu.lib.packet import packet
from ryu.lib.packet.packet import Packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import arp
from ryu.lib.packet import ipv4
from ryu.lib.packet import tcp
from ryu.lib.packet import udp
from ryu.lib.packet import ether_types
from ryu.ofproto import ether
from ryu.app.ofctl.api import get_datapath
from datetime import datetime


# REST API for switch configuration
#
# get switches
# GET /v1.0/lookup/switches
#
# get bridge-table
# GET /v1.0/lookup/bridge-table
#
# get lookup
# GET /v1.0/lookup/lookup
#
# get ip-to-mac
# GET /v1.0/lookup/ip-to-mac

IP     = 0
SUBNET = 1
MAC    = 2
NAME   = 3
DPID   = 4
#########################################################
NROW   = 8   #numero di switch con stessa lunghezza del prefisso (max righe della tabella)

#########################################################

#funzione da decimale a binario
def fromIPtoBinary(string):
	w1, w2, w3, w4 = string.split(".")
	binaryN = [ str(bin(int(w1)))[2:], str(bin(int(w2)))[2:], str(bin(int(w3)))[2:], str(bin(int(w4)))[2:]]
	binaryN = paddingAddress(binaryN)
	addressIP = binaryN[0]
	i=1
	while i<4:
		addressIP = addressIP+binaryN[i]
		i=i+1
	return str(addressIP)

#funzione per portare i vari numeri dell'indirizzo IP a binari a 8 cifre
def paddingAddress(list):
	i = 0
	padded_list = list;
	while i < len(list):
		if len(list)<8:
			while len(padded_list[i]) < 8:
				padded_list[i] = '0' + padded_list[i]
		i = i + 1
	return padded_list
	
	
ipLookUp = [ipLookUp[:] for ipLookUp in [[0]*(32-1)]*31]
marker = [marker[:] for marker in [[0]*(32-1)]*31]
#tabella dei prefissi
ipLookUp[0] = ['']
ipLookUp[1] = ['01','10']
ipLookUp[2] = ['010','100']
ipLookUp[3] = ['1000','1010','1100']
ipLookUp[4] = ['11001']
ipLookUp[5] = ['100001']
ipLookUp[6] = ['1000010']
ipLookUp[7] = ['00001010','11000011','00100001','10111001','00110010','00101100','10011110','10000111']
ipLookUp[8] = ['']
ipLookUp[9] = ['0011001010']
ipLookUp[10] = ['00110010101']
ipLookUp[11] = ['001000010110','101110010101','001011001000','100001111011']
ipLookUp[12] = ['']
ipLookUp[13] = ['00101100100001'] 
ipLookUp[14] = ['001011001000011']                                                                            
ipLookUp[15] = ['0111011111000010','1011100000101101','0100000100110100','1101111100100100','0010110101011000','0011111010000101','1011001101000101']
ipLookUp[16] = ['01110111110000100']
ipLookUp[17] = ['101110000010110100']
ipLookUp[18] = ['1011100000101101001']
ipLookUp[19] = ['01000001001101001110','11011111001001001101']
ipLookUp[20] = ['110111110010010011011']
ipLookUp[21] = ['']
ipLookUp[22] = ['']
ipLookUp[23] = ['001011010101100011110101']
ipLookUp[24] = ['']
ipLookUp[25] = ['']
ipLookUp[26] = ['']
ipLookUp[27] = ['']
ipLookUp[28] = ['']
ipLookUp[29] = ['']
ipLookUp[30] = ['']

#tabella marker
marker[1] = []
marker[3] = []
marker[5] = []

#index di partenza per la ricerca
index = int(round(len(ipLookUp)/2)+1)

#profondita' del percorso dell'algoritmo
deepMax = int(math.log(len(ipLookUp)+1,2))
deep = 0

#dizionario per mappatura prefisso-indirizzo di rete
binary2ip = {}
binary2ip['00001010']='10.0.0.254'
binary2ip['11000011']='195.0.0.254'
binary2ip['001000010110']='33.96.0.254'
binary2ip['101110010101']='185.80.0.254'
binary2ip['1000010']='132.0.0.254'
binary2ip['00110010101']='50.160.0.254'
binary2ip['001011001000011']='44.134.0.254'
binary2ip['1011001101000101']='179.69.0.254'
binary2ip['01110111110000100']='119.194.0.254'
binary2ip['1011100000101101001']='184.45.32.254'
binary2ip['01000001001101001110']='65.52.224.254'
binary2ip['110111110010010011011']='223.36.216.254'
binary2ip['001011010101100011110101']='45.88.245.254'
binary2ip['010']='64.0.0.254'
binary2ip['1010']='160.0.0.254'
binary2ip['11001']='200.0.0.254'
binary2ip['0011111010000101']='62.133.0.254'
binary2ip['10011110']='158.0.0.254'
binary2ip['100001111011']='135.176.0.254'
binary2ip['100']='128.0.0.254'

#costruzione passaggi dell'algoritmo
tree = [tree[:] for tree in [[0]*(31)]*(deepMax)]
for x in range(0,deepMax):
    riga=index
    
    for y in range (0,((2**(x+1))-1)):
     
        tree[x][y]=riga
        riga = riga + index
    
    index = int(index/2)

#variabili globali algoritmo
index = 0
gateway = 0

#ricerca di un valore
def ricerca(ipLookedFor,deepCurrent,index):
    global gateway
    #print "ricercato",ipLookedFor  
    ipCut = ipLookedFor[0:tree[deepCurrent][index]]
    #print "\nipCut: ",ipCut
    #print "index: ",tree[deepCurrent][index]
    #print "Tabella ",ipLookUp[tree[deepCurrent][index]-1]
    trovato = 0
    if(deepCurrent < deepMax):
        if ipCut in ipLookUp[tree[deepCurrent][index]-1]:
            #print "ip trovato"
            #print "Tagliato",ipCut
            gateway = ipCut
            if(deepCurrent < deepMax-1):
                index = tree[deepCurrent+1].index(tree[deepCurrent][index]) +1
        else:
            if ipCut in marker[tree[deepCurrent][index]-1]:
                #print "ho trovato un marker"
                index = tree[deepCurrent+1].index(tree[deepCurrent][index]) +1
            else:
                #print "ip NON trovato"
                if(deepCurrent < deepMax-1):
                    index = tree[deepCurrent+1].index(tree[deepCurrent][index]) -1

    deepCurrent = deepCurrent+1
    
    if (deepCurrent < deepMax and tree[deepCurrent][index] != 0):
        ricerca(ipLookedFor,deepCurrent,index)
    else:
        #print ipCut
        
        return 

########################################################

# Main class for switch
class SimpleSwitch(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_0.OFP_VERSION]
    _CONTEXTS = {
        'wsgi': WSGIApplication
    }

    # Initialize the application 
    def __init__(self, *args, **kwargs):
        super(SimpleSwitch, self).__init__(*args, **kwargs)
        wsgi = kwargs['wsgi']
        wsgi.register(LookupController, {'lookup_api_app': self})

        # Add all initialization code here
        self.mac_to_port = {} 
        self.mac_to_port["1"] = {}
        self.mac_to_port["7"] = {}
        self.mac_to_port["14"] = {}
        self.mac_to_port["18"] = {}
	self.mac_to_port["22"] = {}
	self.mac_to_port["23"] = {}
	self.mac_to_port["26"] = {}
	self.mac_to_port["31"] = {}
	self.mac_to_port["35"] = {}
	self.mac_to_port["38"] = {}
	self.mac_to_port["40"] = {}
	self.mac_to_port["43"] = {}
	self.mac_to_port["45"] = {}
	self.mac_to_port["49"] = {}
	self.mac_to_port["52"] = {}
	self.mac_to_port["53"] = {}
	self.mac_to_port["54"] = {}
	self.mac_to_port["55"] = {}
	self.mac_to_port["56"] = {}
	self.mac_to_port["57"] = {}


        self.mac_to_port["1"]["00:00:00:00:00:01"] = 1
        self.mac_to_port["1"]["00:00:00:00:00:02"] = 2
        self.mac_to_port["7"]["00:00:00:00:00:03"] = 1
        self.mac_to_port["7"]["00:00:00:00:00:04"] = 2
        self.mac_to_port["14"]["00:00:00:00:00:05"] = 1
        self.mac_to_port["14"]["00:00:00:00:00:06"] = 2
        self.mac_to_port["18"]["00:00:00:00:00:07"] = 1
        self.mac_to_port["18"]["00:00:00:00:00:08"] = 2
        self.mac_to_port["22"]["00:00:00:00:00:09"] = 1
	self.mac_to_port["22"]["00:00:00:00:00:0a"] = 2
	self.mac_to_port["22"]["00:00:00:00:00:0b"] = 3
	self.mac_to_port["23"]["00:00:00:00:00:0c"] = 1
	self.mac_to_port["23"]["00:00:00:00:00:0d"] = 2
	self.mac_to_port["23"]["00:00:00:00:00:0e"] = 3
	self.mac_to_port["23"]["00:00:00:00:00:0f"] = 4
	self.mac_to_port["26"]["00:00:00:00:00:10"] = 1
	self.mac_to_port["26"]["00:00:00:00:00:11"] = 2
	self.mac_to_port["31"]["00:00:00:00:00:12"] = 1
	self.mac_to_port["31"]["00:00:00:00:00:13"] = 2
	self.mac_to_port["35"]["00:00:00:00:00:14"] = 1
	self.mac_to_port["35"]["00:00:00:00:00:15"] = 2
	self.mac_to_port["38"]["00:00:00:00:00:16"] = 1
	self.mac_to_port["38"]["00:00:00:00:00:17"] = 2
	self.mac_to_port["40"]["00:00:00:00:00:18"] = 1
	self.mac_to_port["40"]["00:00:00:00:00:19"] = 2
	self.mac_to_port["40"]["00:00:00:00:00:1a"] = 3
	self.mac_to_port["43"]["00:00:00:00:00:1b"] = 1
	self.mac_to_port["43"]["00:00:00:00:00:1c"] = 2
	self.mac_to_port["45"]["00:00:00:00:00:1d"] = 1
	self.mac_to_port["45"]["00:00:00:00:00:1e"] = 2
	self.mac_to_port["49"]["00:00:00:00:00:1f"] = 1
	self.mac_to_port["49"]["00:00:00:00:00:20"] = 2
	self.mac_to_port["52"]["00:00:00:00:00:21"] = 1
	self.mac_to_port["52"]["00:00:00:00:00:22"] = 2
	self.mac_to_port["53"]["00:00:00:00:00:23"] = 1
	self.mac_to_port["53"]["00:00:00:00:00:24"] = 2
	self.mac_to_port["54"]["00:00:00:00:00:25"] = 1
	self.mac_to_port["54"]["00:00:00:00:00:26"] = 2
	self.mac_to_port["54"]["00:00:00:00:00:27"] = 3
	self.mac_to_port["55"]["00:00:00:00:00:28"] = 1
	self.mac_to_port["55"]["00:00:00:00:00:29"] = 2
	self.mac_to_port["55"]["00:00:00:00:00:2a"] = 3
	self.mac_to_port["56"]["00:00:00:00:00:2b"] = 1
	self.mac_to_port["56"]["00:00:00:00:00:2c"] = 2
	self.mac_to_port["56"]["00:00:00:00:00:2d"] = 3
	self.mac_to_port["57"]["00:00:00:00:00:2e"] = 1
	self.mac_to_port["57"]["00:00:00:00:00:2f"] = 2
	self.mac_to_port["57"]["00:00:00:00:00:30"] = 3
	
        self.switch = {}
        self.switch["10.0.0.254"  ] = ["10.0.0.254","8" ,"00:00:00:11:11:01","s1","1"]
        self.switch["195.0.0.254"] = ["195.0.0.254", "8", "00:00:00:11:11:02", "s7", "7"]
        self.switch["33.96.0.254"] = ["33.96.0.254", "12", "00:00:00:11:11:03", "s14", "14"]
        self.switch["185.80.0.254"] = ["185.80.0.254", "12", "00:00:00:11:11:04", "s18", "18"]
        self.switch["132.0.0.254"] = ["132.0.0.254", "7", "00:00:00:11:11:05", "s22", "22"]
	self.switch["50.160.0.254"] = ["50.160.0.254", "11", "00:00:00:11:11:06", "s23", "23"]
	self.switch["44.134.0.254"] = ["44.134.0.254", "15", "00:00:00:11:11:07", "s26", "26"]
	self.switch["179.69.0.254"] = ["179.69.0.254", "16", "00:00:00:11:11:08", "s31", "31"]
	self.switch["119.194.0.254"] = ["119.194.0.254", "17", "00:00:00:11:11:09", "s35", "35"]
	self.switch["184.45.32.254"] = ["184.45.32.254", "19", "00:00:00:11:11:0a", "s38", "38"]
	self.switch["65.52.224.254"] = ["65.52.224.254", "20", "00:00:00:11:11:0b", "s40", "40"]
	self.switch["223.36.216.254"] = ["223.36.216.254", "21", "00:00:00:11:11:0c", "s43", "43"]
	self.switch["45.88.245.254"] = ["45.88.245.254", "24", "00:00:00:11:11:0d", "s45", "45"]
	self.switch["64.0.0.254"] = ["64.0.0.254", "3", "00:00:00:11:11:0e", "s49", "49"]
	self.switch["160.0.0.254"] = ["160.0.0.254", "4", "00:00:00:11:11:0f", "s52", "52"]
	self.switch["200.0.0.254"] = ["200.0.0.254", "5", "00:00:00:11:11:10", "s53", "53"]
	self.switch["62.133.0.254"] = ["62.133.0.254", "16", "00:00:00:11:11:1a", "s54", "54"]
	self.switch["158.0.0.254"] = ["158.0.0.254", "8", "00:00:00:11:11:1b", "s55", "55"]
	self.switch["135.176.0.254"] = ["135.176.0.254", "12", "00:00:00:11:11:1c", "s56", "56"]
	self.switch["128.0.0.254"] = ["128.0.0.254", "3", "00:00:00:11:11:1d", "s57", "57"]
        
	

        self.ip_to_mac = {}
        self.ip_to_mac["10.0.0.1"] = "00:00:00:00:00:01"
        self.ip_to_mac["10.0.0.2"] = "00:00:00:00:00:02"
        self.ip_to_mac["195.0.0.1"] = "00:00:00:00:00:03"
        self.ip_to_mac["195.0.0.2"] = "00:00:00:00:00:04"
        self.ip_to_mac["33.96.0.1"] = "00:00:00:00:00:05"
        self.ip_to_mac["33.96.0.2"] = "00:00:00:00:00:06"
        self.ip_to_mac["185.80.0.1"] = "00:00:00:00:00:07"
        self.ip_to_mac["185.80.0.2"] = "00:00:00:00:00:08"
        self.ip_to_mac["132.0.0.1"] = "00:00:00:00:00:09"
        self.ip_to_mac["132.0.0.2"] = "00:00:00:00:00:0a"
        self.ip_to_mac["132.0.0.3"] = "00:00:00:00:00:0b"
	self.ip_to_mac["50.160.0.1"] = "00:00:00:00:00:0c"
        self.ip_to_mac["50.160.0.2"] = "00:00:00:00:00:0d"
        self.ip_to_mac["50.160.0.3"] = "00:00:00:00:00:0e"
        self.ip_to_mac["50.160.0.4"] = "00:00:00:00:00:0f"
	self.ip_to_mac["44.134.0.1"] = "00:00:00:00:00:10"
        self.ip_to_mac["44.134.0.2"] = "00:00:00:00:00:11"
        self.ip_to_mac["179.69.0.1"] = "00:00:00:00:00:12"
        self.ip_to_mac["179.69.0.2"] = "00:00:00:00:00:13"
        self.ip_to_mac["119.194.0.1"] = "00:00:00:00:00:14"
        self.ip_to_mac["119.194.0.2"] = "00:00:00:00:00:15"
	self.ip_to_mac["184.45.32.1"] = "00:00:00:00:00:16"
        self.ip_to_mac["184.45.32.2"] = "00:00:00:00:00:17"
        self.ip_to_mac["65.52.224.1"] = "00:00:00:00:00:18"
        self.ip_to_mac["65.52.224.2"] = "00:00:00:00:00:19"
        self.ip_to_mac["65.52.224.3"] = "00:00:00:00:00:1a"
        self.ip_to_mac["223.36.216.1"] = "00:00:00:00:00:1b"
        self.ip_to_mac["223.36.216.2"] = "00:00:00:00:00:1c"
	self.ip_to_mac["45.88.245.1"] = "00:00:00:00:00:1d"
        self.ip_to_mac["45.88.245.2"] = "00:00:00:00:00:1e"
	self.ip_to_mac["64.0.0.1"] = "00:00:00:00:00:1f"
        self.ip_to_mac["64.0.0.2"] = "00:00:00:00:00:20"
        self.ip_to_mac["160.0.0.1"] = "00:00:00:00:00:21"
        self.ip_to_mac["160.0.0.2"] = "00:00:00:00:00:22"
        self.ip_to_mac["200.0.0.1"] = "00:00:00:00:00:23"
        self.ip_to_mac["200.0.0.2"] = "00:00:00:00:00:24"
	self.ip_to_mac["62.133.0.1"] = "00:00:00:00:00:25"
        self.ip_to_mac["62.133.0.2"] = "00:00:00:00:00:26"
        self.ip_to_mac["62.133.0.3"] = "00:00:00:00:00:27"
	self.ip_to_mac["158.0.0.1"] = "00:00:00:00:00:28"
        self.ip_to_mac["158.0.0.2"] = "00:00:00:00:00:29"
        self.ip_to_mac["158.0.0.3"] = "00:00:00:00:00:2a"
	self.ip_to_mac["135.176.0.1"] = "00:00:00:00:00:2b"
	self.ip_to_mac["135.176.0.2"] = "00:00:00:00:00:2c"
	self.ip_to_mac["135.176.0.3"] = "00:00:00:00:00:2d"
	self.ip_to_mac["128.0.0.1"] = "00:00:00:00:00:2e"
        self.ip_to_mac["128.0.0.2"] = "00:00:00:00:00:2f"
        self.ip_to_mac["128.0.0.3"] = "00:00:00:00:00:30"

    def send_arp_reply(self, datapath, srcMac, srcIp, dstMac, dstIp, outPort):
        e = ethernet.ethernet(dstMac, srcMac, ether.ETH_TYPE_ARP)
        a = arp.arp(1, 0x0800, 6, 4, 2, srcMac, srcIp, dstMac, dstIp)
        p = Packet()
        p.add_protocol(e)
        p.add_protocol(a)
        p.serialize()

        actions = [datapath.ofproto_parser.OFPActionOutput(outPort, 0)]
        out = datapath.ofproto_parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=0xffffffff,
            in_port=datapath.ofproto.OFPP_CONTROLLER,
            actions=actions,
            data=p.data)
        datapath.send_msg(out)

  
          
    # Register PACKET HANDLER
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg                          # OpenFlow event message
        datapath = msg.datapath               # Switch class that received the packet   
        ofproto = datapath.ofproto            # OpenFlow protocol class  

        # Parse packet
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)

        # Ignore lldp packet
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        dst = eth.dst
        
        src = eth.src
        dpid = datapath.id

        self.logger.info("--Packet IN: Switch id[%s], Src MAC[%s], Dst MAC[%s], Port[%s]", dpid, src, dst, msg.in_port)
        action = "allow"

        if dst == 'ff:ff:ff:ff:ff:ff': 
            self.logger.info("  Broadcast packet")
            if eth.ethertype == ether_types.ETH_TYPE_ARP:
                arp_packet = pkt.get_protocol(arp.arp)
                if arp_packet.opcode == 1:
                    arp_dst_ip = arp_packet.dst_ip
                    arp_src_ip = arp_packet.src_ip
                    self.logger.info("  Received ARP request for dst IP %s" % arp_dst_ip)
                    if arp_dst_ip in self.switch:
                        switch_mac = self.switch[arp_dst_ip][MAC]

                        self.send_arp_reply(datapath,switch_mac,arp_packet.dst_ip,src,arp_src_ip,msg.in_port) 
                        self.logger.info("  Sent gratious ARP reply [%s]-[%s] to %s " % 
                                         (arp_packet.dst_ip,switch_mac,arp_packet.src_ip))  

                        return 0


            actions = [datapath.ofproto_parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
            data = None
            if msg.buffer_id == ofproto.OFP_NO_BUFFER:   #packet is not buffered on switch
                data = msg.data

            out = datapath.ofproto_parser.OFPPacketOut(
                datapath=datapath, buffer_id=msg.buffer_id, in_port=msg.in_port,
                actions=actions, data=data)
            self.logger.info("  Flooding packet to all other ports")
            datapath.send_msg(out)
            return


        ip4_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip4_pkt:
            global gateway
            self.logger.info("  --- IP LOOKUP")
            src_ip = ip4_pkt.src
            dst_ip = ip4_pkt.dst
            self.logger.info("  --- src_ip[%s], dst_ip[%s]" % (src_ip,dst_ip))
            durations = open("/home/user/Downloads/ryu/ryu/app/log_media_p.txt","a")
            ipLookedFor = fromIPtoBinary(dst_ip)
	    t1 = datetime.now()
	    ricerca(ipLookedFor,deep,index);
	    t2 = datetime.now()
	    self.logger.info('\n\n##########Duration: {}'.format(t2 - t1))
	    sw = binary2ip[gateway]
	    durations.write(str(self.switch[sw][1])+'#'+ str((t2-t1).microseconds)+'\r\n')
	    #durations.writelines("\r\nGateway: "+sw);
	    #durations.write('\r\nMask: /' + self.switch[sw][1])
	    #durations.write('\r\nDestination: ' + dst_ip)
	    #durations.write('\r\nSource: ' + src_ip)
	    #durations.write('\r\n##########Duration: {}'.format(t2 - t1))
	    gateway = None
			
            if sw is not None:
            #if dst_ip in self.lookup:
                #sw = self.lookup[dst_ip]
                
                self.logger.info("  --- Destination present on switch %s" % (self.switch[sw]))
                dp = get_datapath(self,int(self.switch[sw][DPID]))

                out_port = self.mac_to_port[self.switch[sw][DPID]][self.ip_to_mac[dst_ip]] 
                self.logger.info("  --- Output port set to %s" % (out_port))

                actions = [dp.ofproto_parser.OFPActionOutput(int(out_port))]

                data = msg.data
                pkt = packet.Packet(data)
                eth = pkt.get_protocol(ethernet.ethernet)
                #change the mac address of packet
                eth.dst = self.ip_to_mac[dst_ip] 
                self.logger.info("  --- Changing destination mac to %s" % (eth.dst))

                pkt.serialize()
                out = dp.ofproto_parser.OFPPacketOut(
                    datapath=dp, buffer_id=0xffffffff, in_port=datapath.ofproto.OFPP_CONTROLLER,
                    actions=actions, data=pkt.data)
                print("---------")
                dp.send_msg(out)
                return





        # Forward the packet 
        if dst in self.mac_to_port[str(dpid)]:
            out_port = self.mac_to_port[str(dpid)][dst]
            self.logger.info("  Destination MAC is on port %s. Forwarding the packet", out_port)
        else:
            out_port =  ofproto.OFPP_FLOOD
            self.logger.info("  Destination MAC not present in table. Flood the packet")

        actions = [datapath.ofproto_parser.OFPActionOutput(int(out_port))]

        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data

        out = datapath.ofproto_parser.OFPPacketOut(
            datapath=datapath, buffer_id=msg.buffer_id, in_port=msg.in_port,
            actions=actions, data=data)
        datapath.send_msg(out)

class LookupController(ControllerBase):
    def __init__(self, req, link, data, **config):
        super(LookupController, self).__init__(req, link, data, **config)
        self.lookup_api_app = data['lookup_api_app']

    @route('lookup', '/v1.0/lookup/lookup',
           methods=['GET'])
    def list_lookup(self, req, **kwargs):
        lookup_table = self.lookup_api_app.lookup
        body = json.dumps(lookup_table, sort_keys=True)
        return Response(content_type='application/json', body=body)

    
    @route('lookup', '/v1.0/lookup/switches',
           methods=['GET'])
    def list_switch(self, req, **kwargs):
        switch_table = self.lookup_api_app.switch
        body = json.dumps(switch_table, sort_keys=True)
        return Response(content_type='application/json', body=body)


    @route('lookup', '/v1.0/lookup/bridge-table',
           methods=['GET'])
    def list_bridge_table(self, req, **kwargs):
        bridge_table = self.lookup_api_app.mac_to_port
        body = json.dumps(bridge_table, sort_keys=True)
        return Response(content_type='application/json', body=body)

    @route('lookup', '/v1.0/lookup/ip-to-mac',
           methods=['GET'])
    def list_ip_to_mac_table(self, req, **kwargs):
        ip_to_mac_table = self.lookup_api_app.ip_to_mac
        body = json.dumps(ip_to_mac_table, sort_keys=True)
        return Response(content_type='application/json', body=body)


