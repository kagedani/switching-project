raccogli = open("param_topogrande_prefix.txt","r")
raccogli_b = open("param_topogrande_binary.txt","r")

valori = []
minimo = []
media = []
massimo = []
devianza = []

valori_b = []
minimo_b = []
media_b = []
massimo_b = []
devianza_b = []

while 1:
	riga=raccogli.readline()
	riga = riga[0:len(riga)-1]
	#print riga
	if riga == "":
		break
	valori=riga.split("/");
	minimo.append(valori[0])
	media.append(valori[1])
	massimo.append(valori[2])
	devianza.append(valori[3])	
raccogli.close();

while 1:
	row=raccogli_b.readline()
	row = row[0:len(row)-1]
	#print row
	if row == "":
		break
	valori_b=row.split("/");
	minimo_b.append(valori_b[0])
	media_b.append(valori_b[1])
	massimo_b.append(valori_b[2])
	devianza_b.append(valori_b[3])	
raccogli_b.close();

import matplotlib.pyplot as plt
x=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
somma=0
somma_b=0
mini=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
mini_b=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
medi=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
medi_b=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
massi=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
massi_b=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
rms=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
rms_b=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41]
#calcolo della media dei valori del binary e del prefix
for i in range(0,len(x)):
	somma = somma + float(minimo[i])
	somma_b = somma_b + float(minimo_b[i])	
for i in range(0,len(x)):
	mini[i] = somma/len(x)
	mini_b[i] = somma_b/len(x)
somma=0
somma_b=0	
	
	
for i in range(0,len(x)):
	somma = somma + float(media[i])
	somma_b = somma_b + float(media_b[i])	
for i in range(0,len(x)):
	medi[i] = somma/len(x)
	medi_b[i] = somma_b/len(x)
somma=0
somma_b=0		
	
for i in range(0,len(x)):
	somma = somma + float(massimo[i])
	somma_b = somma_b + float(massimo_b[i])	
for i in range(0,len(x)):
	massi[i] = somma/len(x)
	massi_b[i] = somma_b/len(x)
somma=0
somma_b=0

for i in range(0,len(x)):
	somma = somma + float(devianza[i])
	somma_b = somma_b + float(devianza_b[i])	
for i in range(0,len(x)):
	rms[i] = somma/len(x)
	rms_b[i] = somma_b/len(x)
	
plt.rcParams['xtick.labelsize'] = 16
plt.rcParams['ytick.labelsize'] = 20

plt.figure(1,figsize=(19,10))
plt.subplots_adjust(left=0.12, bottom=0.26, right=0.90, top=0.90,wspace=0.20, hspace=0.20)
plt.title("Large topology, PING with 500 packets, M tests , Minimum values", fontsize=30)
plt.xticks(x)
plt.plot(x,minimo,label = "Pings' minimum for prefix algorithm")
plt.plot(x,minimo_b,label = "Pings' minimum for binary algorithm")
plt.plot(x,mini,label = "Medium value for prefix algorithm", linestyle='--')
plt.plot(x,mini_b,label = "Medium value for binary algorithm", linestyle='--')
plt.legend(bbox_to_anchor=(1,-0.1),prop={'size': 20})
plt.ylabel("Time [ms]", fontsize=20, weight='bold')
plt.xlabel("M: number of the m Ping ", fontsize=20, weight='bold')
plt.savefig('Grande_minimi.png')

plt.figure(2,figsize=(19,10))
plt.subplots_adjust(left=0.12, bottom=0.26, right=0.90, top=0.90,wspace=0.20, hspace=0.20)
plt.title("Large topology, PING with 500 packets, M tests , Medium values", fontsize=30)
plt.xticks(x)
plt.plot(x,media,label = "Pings' medium for prefix algorithm")
plt.plot(x,media_b,label = "Pings' medium for binary algorithm")
plt.plot(x,medi,label = "Medium value for prefix algorithm", linestyle='--')
plt.plot(x,medi_b,label = "Medium value for binary algorithm", linestyle='--')
plt.legend(bbox_to_anchor=(1,-0.1),prop={'size': 20})
plt.ylabel("Time [ms]", fontsize=20, weight='bold')
plt.xlabel("M: number of the m Ping ", fontsize=20, weight='bold')
plt.savefig('Grande_medi.png')

plt.figure(3,figsize=(19,10))
plt.subplots_adjust(left=0.12, bottom=0.26, right=0.90, top=0.90,wspace=0.20, hspace=0.20)
plt.title("Large topology, PING with 500 packets, M tests , Maximum values", fontsize=30)
plt.xticks(x)
plt.plot(x,massimo, label = "Pings' maximum for prefix algorithm")
plt.plot(x,massimo_b,label = "Pings' maximum for binary algorithm")
plt.plot(x,massi,label = "Medium value for prefix algorithm", linestyle='--')
plt.plot(x,massi_b,label = "Medium value for binary algorithm", linestyle='--')
plt.legend(bbox_to_anchor=(1,-0.1),prop={'size': 20})
plt.ylabel("Time [ms]", fontsize=20, weight='bold')
plt.xlabel("M: number of the m Ping ", fontsize=20, weight='bold')
plt.savefig('Grande_massimi.png')

plt.figure(4,figsize=(19,10))
plt.subplots_adjust(left=0.12, bottom=0.26, right=0.90, top=0.90,wspace=0.20, hspace=0.20)
plt.title("Large topology, PING with 500 packets, M tests , Deviance values", fontsize=30)
plt.xticks(x)
plt.plot(x,devianza, label = "Pings' variance for prefix algorithm")
plt.plot(x,devianza_b,label = "Pings' variance for binary algorithm")
plt.plot(x,rms,label = "Medium value for prefix algorithm", linestyle='--')
plt.plot(x,rms_b,label = "Medium value for binary algorithm", linestyle='--')
plt.legend(bbox_to_anchor=(1,-0.1),prop={'size': 20})
plt.ylabel("Time [ms]", fontsize=20, weight='bold')
plt.xlabel("M: number of the m Ping ", fontsize=20, weight='bold')
plt.savefig('Grande_devianza.png')

plt.show()


    
