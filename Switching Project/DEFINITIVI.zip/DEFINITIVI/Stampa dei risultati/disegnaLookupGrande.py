raccogli = open("log_grande_binary.txt","r")
raccogli_p = open("log_grande_prefix.txt","r")

i=0;
j=0;

maschera = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
maschera_p = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]

valori = []
valori_p = []

media = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
media_p = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

while 1:
	riga=raccogli.readline()
	riga = riga[0:len(riga)-2]

	if riga == "":
		break
	valori=riga.split("#");
	maschera[int(valori[0])].append(int(valori[1]))	


while 1:
	riga_p=raccogli_p.readline()
	riga_p = riga_p[0:len(riga_p)-2]
	
	if riga_p == "":
		break
	valori_p=riga_p.split("#");
	maschera_p[int(valori_p[0])].append(int(valori_p[1]))	
		
for i in range (0,23):
	#print "Maschera: "+str(i)+' Somma :'+str(sum(maschera[i]))
	if len(maschera[i]) != 0:
		#print "Media:"+str(sum(maschera[i])/len(maschera[i]))
		media[i]=sum(maschera[i])/len(maschera[i])
	else:
		media[i]=0
	#print maschera[i]
	#print media
	
for j in range (0,23):
	#print "Maschera prefix: "+str(j)+' Somma :'+str(sum(maschera_p[j]))
	if len(maschera_p[j]) != 0:
		#print "Media:"+str(sum(maschera[i])/len(maschera[i]))
		media_p[j]=sum(maschera_p[j])/len(maschera_p[j])
	else:
		media_p[j]=0
	#print maschera[i]
	#print media_p	
	
	
	
	
	
	
raccogli.close();
raccogli_p.close();

import matplotlib.pyplot as plt

plt.rcParams['xtick.labelsize'] = 20
plt.rcParams['ytick.labelsize'] = 20

x=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
plt.xticks(x)

plt.figure(1,figsize=(15,10))
plt.subplots_adjust(left=0.12, bottom=0.26, right=0.90, top=0.90,wspace=0.20, hspace=0.20)
plt.title("Large topology, PING with 500 packets, N length of the mask", fontsize=30)
plt.plot(x,media,"ro",markersize=15,label = "Mean Lookup time of binary algorithm")
plt.plot(x,media_p,"go",markersize=15,label = "Mean Lookup time of prefix algorithm")

plt.legend(bbox_to_anchor=(1,-0.1),prop={'size': 20})
plt.ylabel("Time [ms]", fontsize=20, weight='bold')
plt.xlabel("N: Length of the mask", fontsize=20, weight='bold')

plt.grid()
#plt.savefig('LookupGrande.png')

plt.show()


    
