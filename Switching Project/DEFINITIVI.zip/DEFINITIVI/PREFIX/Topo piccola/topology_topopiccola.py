from mininet.topo import Topo

class MyTopo( Topo ):
    "Simple topology example."

    def __init__( self ):
        "Create custom topo."

        # Initialize topology
        Topo.__init__( self )

        # Add hosts and switches
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')
        h44 = self.addHost('h44')
        h45 = self.addHost('h45')
        h56 = self.addHost('h56')
        h57 = self.addHost('h57')
        h58 = self.addHost('h58')
        h59 = self.addHost('h59')
        h64 = self.addHost('h64')
        h65 = self.addHost('h65')
        h103 = self.addHost('h103')
        h104 = self.addHost('h104')
        h117 = self.addHost('h117')
        h118 = self.addHost('h118')
        h119 = self.addHost('h119')
        h120 = self.addHost('h120')
        h127 = self.addHost('h127')
        h128 = self.addHost('h128')




        s1 = self.addSwitch('s1')
        s18 = self.addSwitch('s18')
        s23 = self.addSwitch('s23')
        s26 = self.addSwitch('s26')
        s43 = self.addSwitch('s43')
        s48 = self.addSwitch('s48')
        s49 = self.addSwitch('s49')
        s52 = self.addSwitch('s52')
        


        # Add links
        self.addLink(h1, s1)
        self.addLink(h2, s1)
        self.addLink(h44, s18)
        self.addLink(h45, s18)
        self.addLink(h56, s23)
        self.addLink(h57, s23)
        self.addLink(h58, s23)
        self.addLink(h59, s23)
        self.addLink(h64, s26)
        self.addLink(h65, s26)
        self.addLink(h103, s43)
        self.addLink(h104, s43)
        self.addLink(h117, s48)
        self.addLink(h118, s48)
        self.addLink(h119, s49)
        self.addLink(h120, s49)
        self.addLink(h127, s52)
        self.addLink(h128, s52)



topos = { 'mytopo': ( lambda: MyTopo() ) }