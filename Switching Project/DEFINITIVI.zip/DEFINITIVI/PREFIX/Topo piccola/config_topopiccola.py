py "--------------------------------------------------------"
py "Configuring network"
py "--------------------------------------------------------"
py "Assign IP address to hosts"
h1 ifconfig h1-eth0 10.0.0.1/8
h2 ifconfig h2-eth0 10.0.0.2/8
h44 ifconfig h44-eth0 185.80.0.1/12
h45 ifconfig h45-eth0 185.80.0.2/12
h56 ifconfig h56-eth0 50.160.0.1/11
h57 ifconfig h57-eth0 50.160.0.2/11
h58 ifconfig h58-eth0 50.160.0.3/11
h59 ifconfig h59-eth0 50.160.0.4/11
h64 ifconfig h64-eth0 44.134.0.1/15
h65 ifconfig h65-eth0 44.134.0.2/15
h103 ifconfig h103-eth0 200.54.144.1/21
h104 ifconfig h104-eth0 200.54.144.2/21
h117 ifconfig h117-eth0 223.36.220.1/24
h118 ifconfig h118-eth0 223.36.220.2/24
h119 ifconfig h119-eth0 64.0.0.1/3
h120 ifconfig h120-eth0 64.0.0.2/3
h127 ifconfig h127-eth0 160.0.0.1/4
h128 ifconfig h128-eth0 160.0.0.2/4



h1 route add default gw 10.0.0.254
h2 route add default gw 10.0.0.254
h44 route add default gw 185.80.0.254
h45 route add default gw 185.80.0.254
h56 route add default gw 50.160.0.254
h57 route add default gw 50.160.0.254
h58 route add default gw 50.160.0.254
h59 route add default gw 50.160.0.254
h64 route add default gw 44.134.0.254
h65 route add default gw 44.134.0.254
h103 route add default gw 200.54.144.254
h104 route add default gw 200.54.144.254
h117 route add default gw 223.36.220.254
h118 route add default gw 223.36.220.254
h119 route add default gw 64.0.0.254
h120 route add default gw 64.0.0.254
h127 route add default gw 160.0.0.254
h128 route add default gw 160.0.0.254
