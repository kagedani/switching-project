py "--------------------------------------------------------"
py "Configuring network"
py "--------------------------------------------------------"
py "Assign IP address to hosts"
h1 ifconfig h1-eth0 10.0.0.1/8
h2 ifconfig h2-eth0 10.0.0.2/8
h15 ifconfig h15-eth0 195.0.0.1/8
h16 ifconfig h16-eth0 195.0.0.2/8
h33 ifconfig h33-eth0 33.96.0.1/12
h34 ifconfig h34-eth0 33.96.0.2/12
h44 ifconfig h44-eth0 185.80.0.1/12
h45 ifconfig h45-eth0 185.80.0.2/12
h53 ifconfig h53-eth0 132.0.0.1/7
h54 ifconfig h54-eth0 132.0.0.2/7
h55 ifconfig h55-eth0 132.0.0.3/7
h56 ifconfig h56-eth0 50.160.0.1/11
h57 ifconfig h57-eth0 50.160.0.2/11
h58 ifconfig h58-eth0 50.160.0.3/11
h59 ifconfig h59-eth0 50.160.0.4/11
h64 ifconfig h64-eth0 44.134.0.1/15
h65 ifconfig h65-eth0 44.134.0.2/15
h77 ifconfig h77-eth0 179.69.0.1/16
h78 ifconfig h78-eth0 179.69.0.2/16
h85 ifconfig h85-eth0 119.194.0.1/17
h86 ifconfig h86-eth0 119.194.0.2/17
h92 ifconfig h92-eth0 184.45.32.1/19
h93 ifconfig h93-eth0 184.45.32.2/19
h96 ifconfig h96-eth0 65.52.224.1/20
h97 ifconfig h97-eth0 65.52.224.2/20
h98 ifconfig h98-eth0 65.52.224.3/20
h103 ifconfig h103-eth0 223.36.216.1/21
h104 ifconfig h104-eth0 223.36.216.2/21
h108 ifconfig h108-eth0 45.88.245.1/24
h109 ifconfig h109-eth0 45.88.245.2/24
h119 ifconfig h119-eth0 64.0.0.1/3
h120 ifconfig h120-eth0 64.0.0.2/3
h127 ifconfig h127-eth0 160.0.0.1/4
h128 ifconfig h128-eth0 160.0.0.2/4
h129 ifconfig h129-eth0 200.0.0.1/5
h130 ifconfig h130-eth0 200.0.0.2/5
h131 ifconfig h131-eth0 62.133.0.1/16
h132 ifconfig h132-eth0 62.133.0.2/16
h133 ifconfig h133-eth0 62.133.0.3/16
h134 ifconfig h134-eth0 158.0.0.1/8
h135 ifconfig h135-eth0 158.0.0.2/8
h136 ifconfig h136-eth0 158.0.0.3/8
h137 ifconfig h137-eth0 135.176.0.1/12
h138 ifconfig h138-eth0 135.176.0.2/12
h139 ifconfig h139-eth0 135.176.0.3/12
h140 ifconfig h140-eth0 128.0.0.1/3
h141 ifconfig h141-eth0 128.0.0.2/3
h142 ifconfig h142-eth0 128.0.0.3/3



h1 route add default gw 10.0.0.254
h2 route add default gw 10.0.0.254
h15 route add default gw 195.0.0.254
h16 route add default gw 195.0.0.254
h33 route add default gw 33.96.0.254
h34 route add default gw 33.96.0.254
h44 route add default gw 185.80.0.254
h45 route add default gw 185.80.0.254
h53 route add default gw 132.0.0.254
h54 route add default gw 132.0.0.254
h55 route add default gw 132.0.0.254
h56 route add default gw 50.160.0.254
h57 route add default gw 50.160.0.254
h58 route add default gw 50.160.0.254
h59 route add default gw 50.160.0.254
h64 route add default gw 44.134.0.254
h65 route add default gw 44.134.0.254
h77 route add default gw 179.69.0.254
h78 route add default gw 179.69.0.254
h85 route add default gw 119.194.0.254
h86 route add default gw 119.194.0.254
h92 route add default gw 184.45.32.254
h93 route add default gw 184.45.32.254
h96 route add default gw 65.52.224.254
h97 route add default gw 65.52.224.254
h98 route add default gw 65.52.224.254
h103 route add default gw 223.36.216.254
h104 route add default gw 223.36.216.254
h108 route add default gw 45.88.245.254
h109 route add default gw 45.88.245.254
h119 route add default gw 64.0.0.254
h120 route add default gw 64.0.0.254
h127 route add default gw 160.0.0.254
h128 route add default gw 160.0.0.254
h129 route add default gw 200.0.0.254
h130 route add default gw 200.0.0.254
h131 route add default gw 62.133.0.254
h132 route add default gw 62.133.0.254
h133 route add default gw 62.133.0.254
h134 route add default gw 158.0.0.254
h135 route add default gw 158.0.0.254
h136 route add default gw 158.0.0.254
h137 route add default gw 135.176.0.254
h138 route add default gw 135.176.0.254
h139 route add default gw 135.176.0.254
h140 route add default gw 128.0.0.254
h141 route add default gw 128.0.0.254
h142 route add default gw 128.0.0.254
