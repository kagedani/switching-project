py "--------------------------------------------------------"
py "Configuring network"
py "--------------------------------------------------------"
py "Assign IP address to hosts"
h1 ifconfig h1-eth0 10.0.0.1/8
h2 ifconfig h2-eth0 10.0.0.2/8
h3 ifconfig h3-eth0 118.0.0.1/8
h4 ifconfig h4-eth0 118.0.0.2/8
h5 ifconfig h5-eth0 12.0.0.1/6
h6 ifconfig h6-eth0 12.0.0.2/6
h7 ifconfig h7-eth0 12.0.0.3/6
h8 ifconfig h8-eth0 32.204.0.1/14
h9 ifconfig h9-eth0 32.204.0.2/14
h10 ifconfig h10-eth0 38.0.0.1/7
h11 ifconfig h11-eth0 38.0.0.2/7
h15 ifconfig h15-eth0 195.0.0.1/8
h16 ifconfig h16-eth0 195.0.0.2/8
h17 ifconfig h17-eth0 40.0.0.1/5
h18 ifconfig h18-eth0 40.0.0.2/5
h19 ifconfig h19-eth0 163.0.0.1/9
h20 ifconfig h20-eth0 163.0.0.2/9
h21 ifconfig h21-eth0 17.128.0.1/9
h22 ifconfig h22-eth0 17.128.0.2/9
h23 ifconfig h23-eth0 17.128.0.3/9
h24 ifconfig h24-eth0 9.64.0.1/10
h25 ifconfig h25-eth0 9.64.0.2/10
h26 ifconfig h26-eth0 9.64.0.3/10
h27 ifconfig h27-eth0 22.96.0.1/11
h28 ifconfig h28-eth0 22.96.0.2/11
h29 ifconfig h29-eth0 71.96.0.1/11
h30 ifconfig h30-eth0 71.96.0.2/11
h31 ifconfig h31-eth0 71.96.0.3/11
h32 ifconfig h32-eth0 71.96.0.4/11
h33 ifconfig h33-eth0 33.96.0.1/12
h34 ifconfig h34-eth0 33.96.0.2/12
h35 ifconfig h35-eth0 192.0.0.1/8
h36 ifconfig h36-eth0 192.0.0.2/8
h37 ifconfig h37-eth0 193.105.0.1/15
h38 ifconfig h38-eth0 193.105.0.2/15
h39 ifconfig h39-eth0 193.105.0.3/15
h40 ifconfig h40-eth0 220.160.0.1/10
h41 ifconfig h41-eth0 220.160.0.2/10
h42 ifconfig h42-eth0 220.160.0.3/10
h43 ifconfig h43-eth0 220.160.0.4/10
h44 ifconfig h44-eth0 185.80.0.1/12
h45 ifconfig h45-eth0 185.80.0.2/12
h53 ifconfig h53-eth0 132.0.0.1/7
h54 ifconfig h54-eth0 132.0.0.2/7
h55 ifconfig h55-eth0 132.0.0.3/7
h56 ifconfig h56-eth0 50.160.0.1/11
h57 ifconfig h57-eth0 50.160.0.2/11
h58 ifconfig h58-eth0 50.160.0.3/11
h59 ifconfig h59-eth0 50.160.0.4/11
h64 ifconfig h64-eth0 44.134.0.1/15
h65 ifconfig h65-eth0 44.134.0.2/15
h77 ifconfig h77-eth0 179.69.0.1/16
h78 ifconfig h78-eth0 179.69.0.2/16
h85 ifconfig h85-eth0 119.194.0.1/17
h86 ifconfig h86-eth0 119.194.0.2/17
h92 ifconfig h92-eth0 184.45.32.1/19
h93 ifconfig h93-eth0 184.45.32.2/19
h96 ifconfig h96-eth0 65.52.224.1/20
h97 ifconfig h97-eth0 65.52.224.2/20
h98 ifconfig h98-eth0 65.52.224.3/20
h103 ifconfig h103-eth0 223.36.216.1/21
h104 ifconfig h104-eth0 223.36.216.2/21
h108 ifconfig h108-eth0 45.88.245.1/24
h109 ifconfig h109-eth0 45.88.245.2/24
h119 ifconfig h119-eth0 159.0.0.1/3
h120 ifconfig h120-eth0 159.0.0.2/3
h127 ifconfig h127-eth0 180.0.0.1/6
h128 ifconfig h128-eth0 180.0.0.2/6
h129 ifconfig h129-eth0 200.0.0.1/5
h130 ifconfig h130-eth0 200.0.0.2/5
h131 ifconfig h131-eth0 62.133.0.1/16
h132 ifconfig h132-eth0 62.133.0.2/16
h133 ifconfig h133-eth0 62.133.0.3/16
h134 ifconfig h134-eth0 158.0.0.1/8
h135 ifconfig h135-eth0 158.0.0.2/8
h136 ifconfig h136-eth0 158.0.0.3/8
h137 ifconfig h137-eth0 135.176.0.1/12
h138 ifconfig h138-eth0 135.176.0.2/12
h139 ifconfig h139-eth0 135.176.0.3/12
h140 ifconfig h140-eth0 222.0.0.1/9
h141 ifconfig h141-eth0 222.0.0.2/9
h142 ifconfig h142-eth0 222.0.0.3/9
h143 ifconfig h143-eth0 60.0.0.1/7
h144 ifconfig h144-eth0 60.0.0.2/7
h145 ifconfig h145-eth0 216.0.0.1/6
h146 ifconfig h146-eth0 216.0.0.2/6
h147 ifconfig h147-eth0 216.0.0.3/6



h1 route add default gw 10.0.0.254
h2 route add default gw 10.0.0.254
h3 route add default gw 118.0.0.254
h4 route add default gw 118.0.0.254
h5 route add default gw 12.0.0.254
h6 route add default gw 12.0.0.254
h7 route add default gw 12.0.0.254
h8 route add default gw 32.204.0.254
h9 route add default gw 32.204.0.254
h10 route add default gw 38.0.0.254
h11 route add default gw 38.0.0.254
h15 route add default gw 195.0.0.254
h16 route add default gw 195.0.0.254
h17 route add default gw 40.0.0.254
h18 route add default gw 40.0.0.254
h19 route add default gw 163.0.0.254
h20 route add default gw 163.0.0.254
h21 route add default gw 17.128.0.254
h22 route add default gw 17.128.0.254
h23 route add default gw 17.128.0.254
h24 route add default gw 9.64.0.254
h25 route add default gw 9.64.0.254
h26 route add default gw 9.64.0.254
h27 route add default gw 22.96.0.254
h28 route add default gw 22.96.0.254
h29 route add default gw 71.96.0.254
h30 route add default gw 71.96.0.254
h31 route add default gw 71.96.0.254
h32 route add default gw 71.96.0.254
h33 route add default gw 33.96.0.254
h34 route add default gw 33.96.0.254
h35 route add default gw 192.0.0.254
h36 route add default gw 192.0.0.254
h37 route add default gw 193.105.0.254
h38 route add default gw 193.105.0.254
h39 route add default gw 193.105.0.254
h40 route add default gw 220.160.0.254
h41 route add default gw 220.160.0.254
h42 route add default gw 220.160.0.254
h43 route add default gw 220.160.0.254
h44 route add default gw 185.80.0.254
h45 route add default gw 185.80.0.254
h53 route add default gw 132.0.0.254
h54 route add default gw 132.0.0.254
h55 route add default gw 132.0.0.254
h56 route add default gw 50.160.0.254
h57 route add default gw 50.160.0.254
h58 route add default gw 50.160.0.254
h59 route add default gw 50.160.0.254
h64 route add default gw 44.134.0.254
h65 route add default gw 44.134.0.254
h77 route add default gw 179.69.0.254
h78 route add default gw 179.69.0.254
h85 route add default gw 119.194.0.254
h86 route add default gw 119.194.0.254
h92 route add default gw 184.45.32.254
h93 route add default gw 184.45.32.254
h96 route add default gw 65.52.224.254
h97 route add default gw 65.52.224.254
h98 route add default gw 65.52.224.254
h103 route add default gw 223.36.216.254
h104 route add default gw 223.36.216.254
h108 route add default gw 45.88.245.254
h109 route add default gw 45.88.245.254
h119 route add default gw 159.0.0.254
h120 route add default gw 159.0.0.254
h127 route add default gw 180.0.0.254
h128 route add default gw 180.0.0.254
h129 route add default gw 200.0.0.254
h130 route add default gw 200.0.0.254
h131 route add default gw 62.133.0.254
h132 route add default gw 62.133.0.254
h133 route add default gw 62.133.0.254
h134 route add default gw 158.0.0.254
h135 route add default gw 158.0.0.254
h136 route add default gw 158.0.0.254
h137 route add default gw 135.176.0.254
h138 route add default gw 135.176.0.254
h139 route add default gw 135.176.0.254
h140 route add default gw 222.0.0.254
h141 route add default gw 222.0.0.254
h142 route add default gw 222.0.0.254
h143 route add default gw 60.0.0.254
h144 route add default gw 60.0.0.254
h145 route add default gw 216.0.0.254
h146 route add default gw 216.0.0.254
h147 route add default gw 216.0.0.254
